
-- Entidad "decode":
-- Descripci�n: Aqu� se define la etapa de decodificaci�n de la segmentaci�n del 
-- procesador: obtiene del Registro de Instrucci�n (IR) el c�digo de operaci�n de la
-- instrucci�n a ejecutar, lo interpreta y en funci�n del resultado proceder� a
-- obtener la informaci�n sobre los operandos a partir de las se�ales recibidas de la
-- etapa de b�squeda. Luego, en caso de ser necesario, utilizar� dicha informaci�n 
-- para acceder al banco de registros de la CPU y leer de �l los operandos propiamente
-- dichos de la instrucci�n a fin de asignarlos a las etapas que los necesiten para
-- trabajar con ellos. Por ejemplo, si se trata de una instrucci�n aritm�tico/l�gica
-- la etapa "execute" necesitar� algunos de ellos para realizar	la respectiva
-- operaci�n, mientras que la etapa "writeback" deber� conocer en qu� registro se
-- guardar� el resultado; en cambio, si es una instrucci�n de almacenamiento en 
-- memoria, la etapa "memory access" tendr� que saber qu� dato debe ser guardado y a
-- partir de qu� direcci�n de la memoria de datos necesitar� hacerlo. Adem�s, la etapa
-- "decode" ofrece informaci�n adicional obtenida directamente a partir del c�digo de 
-- operaci�n que las siguientes etapas del pipeline tambi�n necesitar�n para ser 
-- llevadas a cabo: el tipo de operaci�n a realizar, el tipo y tama�o de los operandos, 
-- etc.
-- Procesos:
-- Main: En primer lugar, recibe la se�al del administrador de la CPU para comenzar la
-- etapa de decodificaci�n de una nueva instrucci�n. Luego, en la primera mitad del ciclo de
-- reloj comprueba si existen actualmente atascos de alg�n tipo en el cauce, deteniendo
-- temporalmente la ejecuci�n en caso afirmativo. Tambi�n obtiene del registro IR el c�digo
-- de operaci�n de la operaci�n a ejecutar. Finalmente, en la segunda mitad del ciclo 
-- decodifica dicho c�digo, accede en caso de ser necesario al banco de registros para obtener
-- los operandos y configura y env�a toda la informaci�n requerida para que el resto de las 
-- etapas del pipeline puedan realizar su trabajo sin inconvenientes.
-- Procedimientos y funciones:
-- Initialize(): Configura y carga toda la informaci�n inicial para las siguientes etapas
-- del pipeline, antes de que la misma sea modificada durante la decodificaci�n de la
-- instrucci�n: operaciones nulas, operandos y direcciones vac�as, etc.
-- IsALUInst(): (TP10, escenario 4c) Indica si el c�digo de operaci�n corresponde a una
-- instrucci�n aritm�tico-l�gica entera que utiliza la ALU en la etapa "execute".
-- Modificaciones del TP10 (escenario 4c, adelantamiento load -> ALU): antes de decodificar
-- cada instrucci�n, esta etapa le informa al detector de atascos RAW (se�al "FwdEnableID")
-- si se trata de una instrucci�n aritm�tico-l�gica. Luego, cada vez que lee un operando del
-- banco de registros, consulta la se�al "FwdRAW" del detector: si vale '1', el registro le�do
-- tiene pendiente una �nica escritura, correspondiente a un "load" que se encuentra en este
-- mismo ciclo en la etapa "memory access", por lo cual el valor le�do a�n no es el correcto.
-- En lugar de atascar el cauce, se marca el operando (campos "fwd1"/"fwd2" y "fwdreg" de
-- "IDtoEX") para que la etapa "execute" lo reemplace por el valor adelantado desde el
-- registro de segmentaci�n MEM/WB.


library TDA_1819;
use TDA_1819.const_buses.all;
use TDA_1819.const_registros.all;
use TDA_1819.const_cpu.all;
use TDA_1819.repert_cpu.all;
use TDA_1819.tipos_cpu.all;



library ieee;
use ieee.NUMERIC_STD.all;
use ieee.std_logic_1164.all;
library std;
use std.TEXTIO.all;



entity decode is  
	
	generic (
		Pipelining	: BOOLEAN);

    port (
		StallHLT			: out	std_logic;
		StopInit			: out   std_logic;
		DoneID				: out   std_logic;
		IdInstIncWrPend		: out	std_logic_vector(7 downto 0);
		IdRegIncWrPend		: out   std_logic_vector(7 downto 0);
		BranchIDtoSM		: out   state_branch;
		IDtoMA				: out   memaccess_record;
		DataRegInID			: out   std_logic_vector(31 downto 0);
		IdRegID				: out   std_logic_vector(7 downto 0);
		SizeRegID			: out   std_logic_vector(3 downto 0);
		EnableRegID			: out   std_logic;
		EnableRegIDIP		: out   std_logic;
		EnableRegIDSP		: out   std_logic;
		EnableIncWrPend		: out   std_logic;
		EnableIncFPWrPend 	: out	std_logic;
		FwdEnableID			: out	std_logic;		-- TP10 (4c)
		IDtoEX				: inout execute_record;
		IDtoWB				: inout writeback_record;
		StallBrEX			: inout std_logic;
		StallSTR			: in	std_logic;
		StallRAW			: in    std_logic;
		StallWAWAux			: in	std_logic;
		BranchEXALUtoSM		: in    state_branch;
		EXFPUPending		: in	std_logic;
		FwdRAW				: in	std_logic;		-- TP10 (4c)
		IFtoID				: in    decode_record;
		DataRegOutID		: in    std_logic_vector(31 downto 0);
		EnableID			: in    std_logic);

end decode;




architecture decode_architecture of decode is		


	SIGNAL IFtoIDAnt:	decode_record;
	SIGNAL IFtoIDLocal:	decode_record; 
	SIGNAL CodOp:		std_logic_vector(7 downto 0);
	SIGNAL StallBrID:	std_logic;

	-- TP10 (4c): devuelve "true" si el c�digo de operaci�n corresponde a una instrucci�n
	-- aritm�tico-l�gica entera, es decir, una instrucci�n que opera sobre registros de uso
	-- general en la ALU durante la etapa "execute" (tabla 38 del manual del TDA 1819).
	-- S�lo estas instrucciones pueden recibir un operando adelantado desde un "load".
	FUNCTION IsALUInst (cod: std_logic_vector(7 downto 0)) RETURN BOOLEAN IS
	BEGIN
		CASE cod IS
			WHEN DADD | DADDI | DADDU | DADDUI | DSUB | DSUBI | DSUBU |
				 DMUL | DMULU | DDIV | DDIVU | SLT | SLTI |
				 NEGR | ANDR | ANDI | ORR | ORI | XORR | XORI | XNORR | NOTR |
				 DSL | DSLI | DSR | DSRI | DSLS | DSLSI | DSRS | DSRSI =>
				return true;
			WHEN OTHERS =>
				return false;
		END CASE;
	END IsALUInst;

	
begin	
	
		
	Main: PROCESS	
	
	PROCEDURE Initialize (constant idAux: in integer) IS
	
	BEGIN
		IDtoEX.empty <= '1';
		IDtoEX.op <= std_logic_vector(to_unsigned(EX_NULL, IDtoEX.op'length)); 
		IDtoEX.fp <= 'Z';
		IDtoEX.sign <= 'Z';
		IDtoEX.op1 <= "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ";
		IDtoEX.op2 <= "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ";
		IDtoEX.address <= "ZZZZZZZZZZZZZZZZ";
		IDtoEX.fwd1 <= '0';				-- TP10 (4c): por defecto, ning�n operando
		IDtoEX.fwd2 <= '0';				-- se adelanta
		IDtoEX.fwdreg <= "ZZZZZZZZ";

		IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_NULL, IDtoMA.mode'length));
		IDtoMA.control <= NO_ACCESS_MEM;
		IDtoMA.datasize <= "ZZZZ";
		IDtoMA.source <= "ZZZZ";
		IDtoMA.address <= "ZZZZZZZZZZZZZZZZ";
		IDtoMA.data.decode <= "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ"; 
			
		IDtoWB.mode <= std_logic_vector(to_unsigned(WB_NULL, IDtoWB.mode'length));
		IDtoWB.id <= std_logic_vector(to_unsigned(idAux, IDtoWB.mode'length));
		IDtoWB.datasize <= "ZZZZ";
		IDtoWB.source <= std_logic_vector(to_unsigned(WB_NULL, IDtoWB.source'length));
		IDtoWB.data.decode <= "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ";
	End Initialize;	
	
	VARIABLE First:			BOOLEAN := true;
	--VARIABLE wasRAW:		BOOLEAN := false;
	VARIABLE updateCodOp:	BOOLEAN := true;
	VARIABLE rgAux:			INTEGER;
	VARIABLE rfAux:			INTEGER;
	VARIABLE rdAux:			INTEGER;
	VARIABLE addrAux:		INTEGER; 
	VARIABLE idAux:			INTEGER := 0;
	
	BEGIN 
		if (First) then
			First := false;
			StallHLT <= '0';
			StallBrID <= '0';
			StallBrEX <= '0';
			BranchIDtoSM.enable <= '0';
			EnableRegID <= '0';
			EnableRegIDIP <= '0';
			EnableRegIDSP <= '0';
			EnableIncWrPend <= '0';
			EnableIncFPWrPend <= '0';
			FwdEnableID <= '0';		-- TP10 (4c)
			DoneID <= '0';
			StopInit <= '0';
			Initialize(idAux);
			WAIT FOR 1 ns;
		end if;	
		WAIT UNTIL rising_edge(EnableID);
		idAux := idAux + 1;
		if ((StallRAW = '0') and (StallBrID = '0') and (StallBrEX = '0') and (StallSTR = '0') and (StallWAWAux = '0')) then
			IFtoIDLocal <= IFtoID;
		elsif (StallRAW = '1') then
			IFtoIDLocal <= IFtoIDAnt; 
			Initialize(idAux);	
			WAIT UNTIL falling_edge(StallRAW); 
			--WAIT UNTIL rising_edge(EnableID);
			WAIT FOR 1 ns; 
			updateCodOp := false;
		elsif (StallBrID = '1') then
			if (StallSTR = '1') then
				WAIT UNTIL falling_edge(EnableID);
				Initialize(idAux);
				WAIT UNTIL rising_edge(EnableID);
				if (StallSTR = '1') then
					--IFtoIDLocal <= IFtoIDAnt;
					--Initialize(idAux);
					WAIT UNTIL falling_edge(StallSTR);
					WAIT UNTIL rising_edge(EnableID);
					WAIT UNTIL rising_edge(EnableID);
				end if;
			elsif (StallWAWAux = '1') then 
				Initialize(idAux);
				WAIT UNTIL falling_edge(StallWAWAux);
				WAIT FOR 1 ns;
				if (StallSTR = '1') then
					WAIT UNTIL rising_edge(EnableID);
					WAIT UNTIL rising_edge(EnableID); 
					WAIT UNTIL rising_edge(EnableID);
				else
					WAIT UNTIL rising_edge(EnableID);
					WAIT UNTIL rising_edge(EnableID);
				end if;
			else
				WAIT UNTIL falling_edge(EnableID);
				Initialize(idAux);
				WAIT UNTIL rising_edge(EnableID);
				if (StallSTR = '1') then
					WAIT UNTIL falling_edge(StallSTR);
					WAIT UNTIL rising_edge(EnableID);
				end if;
			end if;
			IFtoIDLocal <= IFtoID;
		elsif (StallBrEX = '1') then
			if (StallSTR = '1') then
				--WAIT UNTIL falling_edge(EnableID);
				--Initialize(idAux);
				WAIT UNTIL rising_edge(BranchEXALUtoSM.enable);
				if (BranchEXALUtoSM.branch_taken = '1') then	
					WAIT UNTIL rising_edge(EnableID);
					--WAIT UNTIL rising_edge(EnableID);
					if (StallSTR = '1') then
						WAIT UNTIL falling_edge(StallSTR);
						WAIT UNTIL rising_edge(EnableID);
						WAIT UNTIL rising_edge(EnableID);
						WAIT UNTIL rising_edge(EnableID);
					else
						WAIT UNTIL rising_edge(EnableID);
					end if;
				else  
					Initialize(idAux);
					WAIT UNTIL rising_edge(EnableID);
					if (StallSTR = '1') then
						WAIT UNTIL falling_edge(StallSTR);
						WAIT UNTIL rising_edge(EnableID);
					end if;
				end if;
			else
				WAIT FOR 1 ns;
				if (StallWAWAux = '1') then
					WAIT UNTIL rising_edge(BranchEXALUtoSM.enable);
					Initialize(idAux);
					if (BranchEXALUtoSM.branch_taken = '1') then	
						WAIT UNTIL rising_edge(EnableID);
						if (StallWAWAux = '1') then
							WAIT UNTIL falling_edge(StallWAWAux);
							WAIT UNTIL rising_edge(EnableID);
							if (StallSTR = '1') then
								WAIT UNTIL rising_edge(EnableID);
								WAIT UNTIL rising_edge(EnableID);
							else
								WAIT UNTIL rising_edge(EnableID);
							end if;
						else
							WAIT UNTIL rising_edge(EnableID);
						end if;
					else
						WAIT UNTIL rising_edge(EnableID);
						if (StallWAWAux = '1') then
							WAIT UNTIL falling_edge(StallWAWAux);
							WAIT UNTIL rising_edge(EnableID);
							if (StallSTR = '1') then
								 WAIT UNTIL rising_edge(EnableID);
							end if;
						end if;
					end if;
					IFtoIDLocal <= IFtoID;
				else	
					WAIT UNTIL falling_edge(EnableID);
					Initialize(idAux);
					WAIT UNTIL rising_edge(BranchEXALUtoSM.enable);
					if (BranchEXALUtoSM.branch_taken = '1') then
						WAIT UNTIL rising_edge(EnableID);
						WAIT UNTIL rising_edge(EnableID);
						if (StallSTR = '1') then
							WAIT UNTIL falling_edge(StallSTR);
							WAIT UNTIL rising_edge(EnableID);
							WAIT UNTIL rising_edge(EnableID);
						end if;
					else
						WAIT UNTIL rising_edge(EnableID); 
						if (StallSTR = '1') then
							WAIT UNTIL falling_edge(StallSTR);
							WAIT UNTIL rising_edge(EnableID);
						end if;
					end if;	
				end if;
			end if;
			IFtoIDLocal <= IFtoID;
		elsif (StallSTR = '1') then
			IFtoIDLocal <= IFtoIDAnt;
			--Initialize(idAux);
			WAIT UNTIL falling_edge(StallSTR); 
			if (StallWAWAux = '1') then
				WAIT UNTIL falling_edge(StallWAWAux);
			end if;
			WAIT UNTIL rising_edge(EnableID);
			IFtoIDLocal <= IFtoID;
			--updateCodOp := false;
		elsif (StallWAWAux = '1') then
			IFtoIDLocal <= IFtoIDAnt; 
			--Initialize(idAux);
			WAIT UNTIL falling_edge(StallWAWAux);
			WAIT FOR 1 ns;
			if (StallSTR = '1') then
				WAIT UNTIL rising_edge(EnableID);
				WAIT UNTIL rising_edge(EnableID);
			else
				WAIT UNTIL rising_edge(EnableID);
			end if;
			IFtoIDLocal <= IFtoID;
			--updateCodOp := false;
		end if;
		StallBrID <= '0';
		StallBrEX <= '0';
		IdInstIncWrPend <= IDtoWB.id;
		IdRegIncWrPend <= IDtoWB.mode;
		EnableIncWrPend <= '1';	
		if (IDtoEX.fp = '1') then
			EnableIncFPWrPend <= '1';
		end if;
		WAIT FOR 1 ns;
		EnableIncWrPend <= '0';
		EnableIncFPWrPend <= '0';
		WAIT FOR 1 ns;
		if (updateCodOp) then
			IdRegID <= std_logic_vector(to_unsigned(ID_IR, IdRegID'length));
			SizeRegID <= std_logic_vector(to_unsigned(1, SizeRegID'length));
			EnableRegID <= '1';
			WAIT FOR 1 ns;
			EnableRegID <= '0';
			WAIT FOR 1 ns;
			CodOp <= DataRegOutID(7 downto 0);
		else
			updateCodOp := true;
		end if;
		--IFtoIDLocal <= IFtoID;

		WAIT UNTIL falling_edge(EnableID);
		Initialize(idAux);
		IDtoEX.empty <= '0';
		-- TP10 (4c): se informa al detector de atascos RAW si la instrucci�n que se est�
		-- decodificando es aritm�tico-l�gica (entera, ejecutada en la ALU). S�lo para
		-- ellas se permite adelantar el operando le�do por un "load" en "memory access".
		if (IsALUInst(CodOp)) then
			FwdEnableID <= '1';
		else
			FwdEnableID <= '0';
		end if;
		CASE CodOp IS
			WHEN LB =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= READ_DATA_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(1, IDtoMA.datasize'length));
				IDtoWB.datasize <= std_logic_vector(to_unsigned(1, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_MEM, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
				IdRegID <= IFtoIDLocal.package2(7 downto 0);
				SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length)); 
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
				IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
			WHEN SB =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= WRITE_DATA_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(1, IDtoMA.datasize'length));
				IDtoMA.source <= std_logic_vector(to_unsigned(MEM_ID, IDtoMA.source'length));
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(1, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoMA.data.decode(7 downto 0) <= DataRegOutID(7 downto 0);
				if (StallRAW = '0') then
					addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
					IdRegID <= IFtoIDLocal.package2(7 downto 0);
					SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
					IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
				end if;
			WHEN LH =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.datasize <= std_logic_vector(to_unsigned(2, IDtoMA.datasize'length));
				IDtoWB.datasize <= std_logic_vector(to_unsigned(2, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_MEM, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
				if (to_integer(unsigned(IFtoIDLocal.package2(7 downto 0))) = ID_SP) then
					IDtoMA.control <= READ_STACK_MEM;
				else
					IDtoMA.control <= READ_DATA_MEM;
				end if;
				IdRegID <= IFtoIDLocal.package2(7 downto 0);
				SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
				IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
			WHEN SH =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.datasize <= std_logic_vector(to_unsigned(2, IDtoMA.datasize'length));
				IDtoMA.source <= std_logic_vector(to_unsigned(MEM_ID, IDtoMA.source'length));
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoMA.data.decode(15 downto 0) <= DataRegOutID(15 downto 0);
				if (StallRAW = '0') then
					addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
					if (to_integer(unsigned(IFtoIDLocal.package2(7 downto 0))) = ID_SP) then
						IDtoMA.control <= WRITE_STACK_MEM;
					else
						IDtoMA.control <= WRITE_DATA_MEM;
					end if;
					IdRegID <= IFtoIDLocal.package2(7 downto 0);
					SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
					IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
				end if;
			WHEN LW =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= READ_DATA_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(4, IDtoMA.datasize'length));
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_MEM, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
				IdRegID <= IFtoIDLocal.package2(7 downto 0);
				SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
				IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
			WHEN SW => 
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= WRITE_DATA_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(4, IDtoMA.datasize'length));
				IDtoMA.source <= std_logic_vector(to_unsigned(MEM_ID, IDtoMA.source'length));
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoMA.data.decode(31 downto 0) <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') then
					addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
					IdRegID <= IFtoIDLocal.package2(7 downto 0);
					SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
					IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length)); 
				end if;
			WHEN TDA_1819.repert_cpu.LF =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= READ_DATA_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(4, IDtoMA.datasize'length));
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_MEM, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
				IdRegID <= IFtoIDLocal.package2(7 downto 0);
				SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
				IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
			WHEN SF =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= WRITE_DATA_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(4, IDtoMA.datasize'length));
				IDtoMA.source <= std_logic_vector(to_unsigned(MEM_ID, IDtoMA.source'length));
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoMA.data.decode(31 downto 0) <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') then
					addrAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 8)));
					IdRegID <= IFtoIDLocal.package2(7 downto 0);
					SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					addrAux := addrAux + to_integer(unsigned(DataRegOutID(15 downto 0)));
					IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length)); 
				end if;
			WHEN MFF =>
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_ID, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length)); 
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoWB.data.decode(31 downto 0) <= DataRegOutID(31 downto 0); 
			WHEN MFR =>
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_ID, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length)); 
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoWB.data.decode(31 downto 0) <= DataRegOutID(31 downto 0);  
			WHEN MRF =>
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_ID, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length)); 
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoWB.data.decode(31 downto 0) <= DataRegOutID(31 downto 0);
			WHEN TF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_TF, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
			WHEN TI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_TI, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);	
			WHEN DADD =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_ADD, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns; 
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DADDI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_ADD, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN DADDU =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_ADD, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DADDUI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_ADD, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN ADDF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_ADD, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns; 
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
				end if;
			WHEN DSUB =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_SUB, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DSUBI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_SUB, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));				
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN DSUBU =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_SUB, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 	
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN SUBF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_SUB, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
				end if;
			WHEN DMUL =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_MUL, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DMULU =>
		  		IDtoEX.op <= std_logic_vector(to_unsigned(EX_MUL, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN MULF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_MUL, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
				end if;
			WHEN DDIV =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DIV, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);   
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DDIVU =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DIV, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);	
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DIVF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DIV, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
				end if;
			WHEN SLT =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_SLT, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN SLTI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_SLT, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN LTF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_LTF, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
				end if;
			WHEN LEF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_LEF, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
				end if;
			WHEN EQF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_EQF, IDtoEX.op'length));
				IDtoEX.fp <= '1';
				IDtoEX.sign <= '1';	
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
				end if;
			WHEN NEGR =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_NEG, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN ANDR =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_AND, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN ANDI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_AND, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN ORR =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_OR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN ORI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_OR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN XORR =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_XOR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN XORI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_XOR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN XNORR =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_XNOR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN NOTR =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_NOT, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN DSL =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSL, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DSLI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSL, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN DSR =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DSRI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN DSLS =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSL, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DSLSI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSL, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN DSRS =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				rgAux := to_integer(unsigned(IFtoIDLocal.package1(23 downto 16)));
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rgAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);  
					if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
						IDtoEX.fwd2 <= '1';
						IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rgAux, IDtoEX.fwdreg'length));
					end if;
				end if;
			WHEN DSRSI =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_DSR, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '1';
				IDtoWB.datasize <= std_logic_vector(to_unsigned(4, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_EX, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.op2(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.op2(31 downto 8) <= IFtoIDLocal.package2(23 downto 0);
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (FwdRAW = '1') then		-- TP10 (4c): operando a adelantar desde MEM/WB
					IDtoEX.fwd1 <= '1';
					IDtoEX.fwdreg <= std_logic_vector(to_unsigned(rfAux, IDtoEX.fwdreg'length));
				end if;
			WHEN JMP =>	
				DataRegInID(31 downto 16) <= "ZZZZZZZZZZZZZZZZ";
				DataRegInID(15 downto 0) <= IFtoIDLocal.package1(15 downto 0);
				if (Pipelining) then
					StallBrID <= '1';
				end if;
				BranchIDtoSM.branch_taken <= '1';
				BranchIDtoSM.enable <= '1';
				EnableRegIDIP <= '1';
				WAIT FOR 1 ns;
				BranchIDtoSM.enable <= '0';
				EnableRegIDIP <= '0';
				WAIT FOR 1 ns;
			WHEN BEQ =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_BEQ, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.address(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.address(15 downto 8) <= IFtoIDLocal.package2(7 downto 0);
				--StallBrEX <= '1';
				IdRegID <= std_logic_vector(to_unsigned(rdAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0); 
				end if;
				if (StallRAW = '0') and (Pipelining) then
					StallBrEX <= '1';
				end if;
			WHEN BNE =>
		  		IDtoEX.op <= std_logic_vector(to_unsigned(EX_BNE, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(15 downto 8)));
				IDtoEX.address(7 downto 0) <= IFtoIDLocal.package1(23 downto 16);
				IDtoEX.address(15 downto 8) <= IFtoIDLocal.package2(7 downto 0);
				--StallBrEX <= '1';
				IdRegID <= std_logic_vector(to_unsigned(rdAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);  
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					IDtoEX.op2 <= DataRegOutID(31 downto 0);
				end if;
				if (StallRAW = '0') and (Pipelining) then
					StallBrEX <= '1';
				end if;
			WHEN BEQZ =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_BEQZ, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				IDtoEX.address <= IFtoIDLocal.package1(23 downto 8);
				--StallBrEX <= '1';
				IdRegID <= std_logic_vector(to_unsigned(rdAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') and (Pipelining) then
					StallBrEX <= '1';
				end if;
			WHEN BNEZ =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_BNEZ, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				IDtoEX.address <= IFtoIDLocal.package1(23 downto 8);
				--StallBrEX <= '1';
				IdRegID <= std_logic_vector(to_unsigned(rdAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(4, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0); 
				if (StallRAW = '0') and (Pipelining) then
					StallBrEX <= '1';
				end if;
			WHEN BFPT =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_BFPT, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoEX.address <= IFtoIDLocal.package1(15 downto 0);
				--StallBrEX <= '1';
				IdRegID <= std_logic_vector(to_unsigned(ID_FPFLAGS, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(1, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (StallRAW = '0') and (Pipelining) then
					StallBrEX <= '1';
				end if;
			WHEN BFPF =>
				IDtoEX.op <= std_logic_vector(to_unsigned(EX_BFPF, IDtoEX.op'length));
				IDtoEX.fp <= '0';
				IDtoEX.sign <= '0';
				IDtoEX.address <= IFtoIDLocal.package1(15 downto 0);
				--StallBrEX <= '1'; 
				IdRegID <= std_logic_vector(to_unsigned(ID_FPFLAGS, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(1, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoEX.op1 <= DataRegOutID(31 downto 0);
				if (StallRAW = '0') and (Pipelining) then
					StallBrEX <= '1';
				end if;
			WHEN PUSHH =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= WRITE_STACK_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(2, IDtoMA.datasize'length));
				IDtoMA.source <= std_logic_vector(to_unsigned(MEM_ID, IDtoMA.source'length));
				rfAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0)));
				IdRegID <= std_logic_vector(to_unsigned(rfAux, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoMA.data.decode(15 downto 0) <= DataRegOutID(15 downto 0); 
				if (StallRAW = '0') then
					IdRegID <= std_logic_vector(to_unsigned(ID_SP, IdRegID'length));
					SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
					EnableRegID <= '1';
					WAIT FOR 1 ns;
					EnableRegID <= '0';
					WAIT FOR 1 ns;
					addrAux := to_integer(unsigned(DataRegOutID(15 downto 0))) - 2;
					IDtoMA.address <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
					DataRegInID(31 downto 16) <= "ZZZZZZZZZZZZZZZZ";
					DataRegInID(15 downto 0) <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
					EnableRegIDSP <= '1';
					WAIT FOR 1 ns;
					EnableRegIDSP <= '0';
					WAIT FOR 1 ns;
				end if;				
			WHEN POPH =>
				IDtoMA.mode <= std_logic_vector(to_unsigned(MEM_MEM, IDtoMA.mode'length));
				IDtoMA.control <= READ_STACK_MEM;
				IDtoMA.datasize <= std_logic_vector(to_unsigned(2, IDtoMA.datasize'length));
				IDtoWB.datasize <= std_logic_vector(to_unsigned(2, IDtoWB.datasize'length));
				IDtoWB.source <= std_logic_vector(to_unsigned(WB_MEM, IDtoWB.source'length));
				rdAux := to_integer(unsigned(IFtoIDLocal.package1(7 downto 0))) + 1;
				IDtoWB.mode <= std_logic_vector(to_unsigned(rdAux, IDtoWB.mode'length));
				IdRegID <= std_logic_vector(to_unsigned(ID_SP, IdRegID'length));
				SizeRegID <= std_logic_vector(to_unsigned(2, SizeRegID'length));
				EnableRegID <= '1';
				WAIT FOR 1 ns;
				EnableRegID <= '0';
				WAIT FOR 1 ns;
				IDtoMA.address <= DataRegOutID(15 downto 0);
				addrAux := to_integer(unsigned(DataRegOutID(15 downto 0))) + 2;
				DataRegInID(31 downto 16) <= "ZZZZZZZZZZZZZZZZ";
				DataRegInID(15 downto 0) <= std_logic_vector(to_unsigned(addrAux, IDtoMA.address'length));
				EnableRegIDSP <= '1';
				WAIT FOR 1 ns;
				EnableRegIDSP <= '0';
				WAIT FOR 1 ns;
			WHEN NOP =>
				WAIT FOR 1 ns;
			WHEN HALT =>  
				Initialize(idAux); 
				WAIT FOR 2 ns; 
				if (EXFPUPending = '1') then
					StallHLT <= '1';
					DoneID <= '1';
					WAIT FOR 1 ns;
					DoneID <= '0';
					WAIT UNTIL falling_edge(EXFPUPending);
					StallHLT <= '0';
					if (StallSTR = '1') then
						WAIT UNTIL falling_edge(StallSTR); 
						WAIT UNTIL falling_edge(EnableID);
					end if;
				elsif (StallWAWAux = '1') then
					StallHLT <= '1';
					DoneID <= '1';
					WAIT FOR 1 ns;
					DoneID <= '0';
					WAIT UNTIL falling_edge(StallWAWAux);
					StallHLT <= '0';
					WAIT FOR 1 ns;
					if (StallSTR = '1') then
						WAIT UNTIL falling_edge(StallSTR); 
						WAIT UNTIL falling_edge(EnableID);
						WAIT UNTIL falling_edge(EnableID);
					end if;
				else
					WAIT FOR 1 ns;
					if (StallSTR = '1') then
						StallHLT <= '1';
						DoneID <= '1';
						WAIT FOR 1 ns;
						DoneID <= '0';
						WAIT UNTIL falling_edge(StallSTR);
						StallHLT <= '0'; 
						WAIT UNTIL falling_edge(EnableID);
					end if;
				end if;
				StopInit <= '1';
			WHEN OTHERS =>
				report "Error: el c�digo de operaci�n de la instrucci�n no es v�lido"
				severity FAILURE;
		END CASE;
		FwdEnableID <= '0';		-- TP10 (4c)
		IFtoIDAnt <= IFtoIDLocal;
		--IdRegIncWrPend <= IDtoWB.mode;
		--EnableIncWrPend <= '1';
		DoneID <= '1';
		WAIT FOR 1 ns;
		--EnableIncWrPend <= '0';
		DoneID <= '0';
		WAIT FOR 1 ns;
		if (StallRAW = '1') then
			Initialize(idAux);
		end if;
	END PROCESS Main;					
	

end decode_architecture;